package com.liveMatchComentatory.liveMatchComentatory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiveMatchComentatoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiveMatchComentatoryApplication.class, args);
	}

}
