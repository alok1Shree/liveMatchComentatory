package com.liveMatchComentatory.liveMatchComentatory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveMatchComentatoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
